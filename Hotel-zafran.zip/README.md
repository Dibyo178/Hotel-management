# hotel-al-istiqomah-template

![Screenshot_20](https://user-images.githubusercontent.com/38512012/194867453-7f15be40-9537-44f1-8620-0749fa39bb2f.png)
![Screenshot_21](https://user-images.githubusercontent.com/38512012/194867510-a71f0c31-2b22-4571-9587-6b0977647803.png)


